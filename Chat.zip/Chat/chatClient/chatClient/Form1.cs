using SimpleTCP;
using System.Text;

namespace chatClient
{
    public partial class Form1 : Form
    {
        string korisnickoIme = "";
        SimpleTcpClient client = new SimpleTcpClient();
        string boxMessage = "";
        public Form1()
        {
            InitializeComponent();
            client.DataReceived += (sender, e) => {
                var poruka = Encoding.UTF8.GetString(e.Data);
                char[] porukaCharr = poruka.ToString().ToCharArray();

                string[] porukaSplit = poruka.ToString().Split(" ");

                if (porukaSplit[0] == "#.#")
                {
                    korisnickoIme += porukaSplit[1] + " " + porukaSplit[2] + ": ";
                    listBox1.Items.Add(korisnickoIme);
                }

                if (poruka.Contains(":"))
                {
                    listBox1.Items.Add(poruka);
                }
            };
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (textBox3.Text.ToString() == "")
            {
                boxMessage = "Unesi korisnicko ime!";
                MessageBox.Show(boxMessage);
            }
            else
            {
                try
                {
                    client.Connect(textBox1.Text.ToString(), int.Parse(textBox2.Text.ToString())); ;
                    client.Write("#.# " + textBox3.Text.ToString());

                    button2.Enabled = false;
                    textBox1.Enabled = false;
                    textBox2.Enabled = false;
                    textBox3.Enabled = false;
                }
                catch
                {
                    boxMessage = "Krivi port ili IP adresa";
                    MessageBox.Show(boxMessage);
                }
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (textBox4.Text.ToString() == "")
            {
                boxMessage = "Ne mo�ete poslati praznu poruku";
                MessageBox.Show(boxMessage);
            }
            else
            {
                label6.Text = "";
                client.Write(Encoding.UTF8.GetBytes(korisnickoIme + textBox4.Text.ToString()));
            }
        }

        private void ucitajToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (File.Exists(@"E:\spremaj.txt"))
            {
                string[] ucitano = File.ReadAllLines(@"E:\spremaj.txt");
                textBox2.Text = ucitano[0];
                textBox1.Text = ucitano[1];
            }
        }

        private void spremiToolStripMenuItem_Click_1(object sender, EventArgs e)
        {
            string spremljeno = (textBox2.Text + "\n" + textBox1.Text);
            File.WriteAllText(@"E:\spremaj.txt", spremljeno);
        }
    }
}