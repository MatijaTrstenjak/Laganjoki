using SimpleTCP;
using System.Text;

namespace chatServer
{
    public partial class Form1 : Form
    {
        SimpleTcpServer server = new SimpleTcpServer();
        int id = 0;
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            server.ClientConnected += (sender, e) => {
                listBox1.Items.Add($"Spojil se: ({e.Client.RemoteEndPoint})");
            };

            server.ClientDisconnected += (sender, e) => listBox1.Items.Add($"Oti�ao je ({e.Client.RemoteEndPoint})");
            server.DataReceived += (server2, e) =>
            {
                var ep = e.TcpClient.Client.RemoteEndPoint;
                var msg = Encoding.UTF8.GetString(e.Data);
                listBox1.Items.Add($"{ep}: \"{msg}\".");

                string[] ok = msg.ToString().Split(" ");

                if (msg.Contains("#.#"))
                {
                    e.Reply("#.# " + id.ToString() + " " + ok[1]);
                    id++;
                }
                if (msg.Contains(":"))
                {
                    server.Broadcast(Encoding.UTF8.GetBytes(msg.ToString()));
                }
            };

            try
            {
                server.Start(int.Parse(textBox1.Text));
            }
            catch { }
        }
    }
}