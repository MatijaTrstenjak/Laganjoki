﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace charKlijent {
    public partial class Form1 : Form {
        public Form1() {
            InitializeComponent();
        }

        Thread clientChatThread = null;
        TcpClient client= null;
        string korisnickoIme = "";
        Int32 port = 50100;
        List<string> chat = new List<string>();
        string imeAndPorukaSalji = "";
        string imeAndPorukaPrimi = "";
        bool started = false;

        private void joinChatToolStripMenuItem_Click(object sender, EventArgs e) {
            try {
                korisnickoIme = textBox3.Text;
                started = true;

                clientChatThread = new Thread(Chat);
                label5.Invoke((MethodInvoker)(() => label5.Text = "DA"));
                clientChatThread.Start();

            } catch { }
        }
        TcpClient tcpclnt = new TcpClient();
        private void Chat() {
           
            client = new TcpClient(textBox1.Text, port);
            while (started) {
                Byte[] data = new Byte[256];
                NetworkStream stream = client.GetStream();
                imeAndPorukaPrimi = "";
                Int32 bytes = stream.Read(data, 0, data.Length);
                imeAndPorukaPrimi = System.Text.Encoding.ASCII.GetString(data, 0, bytes);
                stream.Close();
                if (imeAndPorukaPrimi != "")
                    unesiListBox();
            }
        }

        private void unesiListBox() {
            listBox1.Items.Clear();
            for (int i = 0; i < chat.Count; i++)
                listBox1.Items.Add(chat[i]);
        }

        private void button1_Click(object sender, EventArgs e) {                //ŠALJI PORUKU
            imeAndPorukaSalji = korisnickoIme + ": " + porukaBox.Text;
            Byte[] data = System.Text.Encoding.ASCII.GetBytes(imeAndPorukaSalji);
            NetworkStream stream = client.GetStream();
            chat.Add(imeAndPorukaSalji);
            stream.Close();
            unesiListBox();
        }
    }
}
