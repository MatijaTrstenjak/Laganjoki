﻿namespace charKlijent {
    internal class Tcpclient {
    }
}