﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace chatServer {
    public partial class Form1 : Form {
        public Form1() {
            InitializeComponent();
        }
        TcpClient client = null;
        TcpListener server = null;
        Thread serverChatThread = null;

        Int32 port = 50100;
        IPAddress localAddr = IPAddress.Parse("127.0.0.1");
        
        int brojac = 0;
        bool started = true;

        private void startServerToolStripMenuItem_Click(object sender, EventArgs e) {
            try {
                label2.Invoke((MethodInvoker)(() => label2.Text = "Started"));
                started = true;
                serverChatThread = new Thread(serverChat);
                serverChatThread.Start();
            } catch { }
        }


        private void serverChat() {
            server = new TcpListener(localAddr, port);
            brojac++;
            try {
                Byte[] bytes = new Byte[256];
                String data = null;

                // Enter the listening loop.
                while (true) {

                    // Perform a blocking call to accept requests.
                    // You could also use server.AcceptSocket() here.
                    client = server.AcceptTcpClient();
                    label2.Invoke((MethodInvoker)(() => label2.Text = "Connected"));

                    data = null;

                    NetworkStream stream = client.GetStream();

                    int i;

                    // Loop to receive all the data sent by the client.
                    while ((i = stream.Read(bytes, 0, bytes.Length)) != 0) {
                        // Translate data bytes to a ASCII string.
                        data = System.Text.Encoding.ASCII.GetString(bytes, 0, i);

                        // Process the data sent by the client.
                        data = data.ToUpper();

                        byte[] msg = System.Text.Encoding.ASCII.GetBytes(data);

                        // Send back a response.
                        stream.Write(msg, 0, msg.Length);
                        //Console.WriteLine("Sent: {0}", data);
                    }
                }
            } catch { }
        }
    }
}
