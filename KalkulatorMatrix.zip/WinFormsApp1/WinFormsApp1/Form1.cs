﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Diagnostics;

namespace WinFormsApp1
{
    public partial class Form1 : Form
    {
        float[,] matA = new float[4,4];
        float[,] matB = new float[4,4];
        float[,] matC = new float[4,4];
 

        public Form1()
        {
            InitializeComponent();
        }

        private void enable2x2()
        {
            foreach (Control text in panel2x2A.Controls)
            {
                if (text is TextBox)
                {
                    ((TextBox)text).Visible = true;
                }
            }

            foreach (Control text in panel2x2B.Controls)
            {
                if (text is TextBox)
                {
                    ((TextBox)text).Visible = true;
                }
            }

            foreach (Control text in panel2x2C.Controls)
            {
                if (text is TextBox)
                {
                    ((TextBox)text).Visible = true;
                }
            }
        }

        private void enable3x3()
        {
            enable2x2();
            foreach (Control text in panel3x3A.Controls)
            {
                if (text is TextBox)
                {
                    ((TextBox)text).Visible = true;
                }
            }

            foreach (Control text in panel3x3B.Controls)
            {
                if (text is TextBox)
                {
                    ((TextBox)text).Visible = true;
                }
            }

            foreach (Control text in panel3x3C.Controls)
            {
                if (text is TextBox)
                {
                    ((TextBox)text).Visible = true;
                }
            }
        }

        private void enable4x4()
        {
            enable3x3();
            foreach (Control text in panel4x4A.Controls)
            {
                if (text is TextBox)
                {
                    ((TextBox)text).Visible = true;
                }
            }

            foreach (Control text in panel4x4B.Controls)
            {
                if (text is TextBox)
                {
                    ((TextBox)text).Visible = true;
                }
            }

            foreach (Control text in panel4x4C.Controls)
            {
                if (text is TextBox)
                {
                    ((TextBox)text).Visible = true;
                }
            }

        }

        private void popuni2x2()
        {
            Random rnd = new Random();
            foreach(Control text in panel2x2A.Controls)
            {
                if (text is TextBox)
                {
                    ((TextBox)text).Text = (rnd.Next(20) - 10).ToString();
                    //((TextBox)text).Text = Math.Round(rnd.NextDouble() + rnd.Next(20) - 10, 2).ToString();
                }
            }
            foreach (Control text in panel2x2B.Controls)
            {
                if (text is TextBox)
                {
                    ((TextBox)text).Text = (rnd.Next(20) - 10).ToString();
                }
            }
        }

        private void popuni3x3()
        {
            popuni2x2();
            Random rnd = new Random();
            foreach (Control text in panel3x3A.Controls)
            {
                if (text is TextBox)
                {
                    ((TextBox)text).Text = (rnd.Next(20) - 10).ToString();
                }
            }
            foreach (Control text in panel3x3B.Controls)
            {
                if (text is TextBox)
                {
                    ((TextBox)text).Text = (rnd.Next(20) - 10).ToString();
                }
            }
        }

        private void popuni4x4()
        {
            popuni3x3();
            Random rnd = new Random();
            foreach (Control text in panel4x4A.Controls)
            {
                if (text is TextBox)
                {
                    ((TextBox)text).Text = (rnd.Next(20) - 10).ToString();
                }
            }
            foreach (Control text in panel4x4B.Controls)
            {
                if (text is TextBox)
                {
                    ((TextBox)text).Text = (rnd.Next(20) - 10).ToString();
                }
            }
        }

        private void textToPolje2x2()
        {
            matA[0, 0] = float.Parse(textBox1.Text);
            matA[0, 1] = float.Parse(textBox2.Text);
            matA[1, 0] = float.Parse(textBox3.Text);
            matA[1, 1] = float.Parse(textBox4.Text);

            matB[0, 0] = float.Parse(textBox48.Text);
            matB[0, 1] = float.Parse(textBox47.Text);
            matB[1, 0] = float.Parse(textBox46.Text);
            matB[1, 1] = float.Parse(textBox45.Text);

        }
        private void textToPolje3x3()
        {
            textToPolje2x2();
            matA[2, 0] = float.Parse(textBox5.Text);
            matA[2, 1] = float.Parse(textBox6.Text);
            matA[2, 2] = float.Parse(textBox7.Text);
            matA[0, 2] = float.Parse(textBox9.Text);
            matA[1, 2] = float.Parse(textBox8.Text);

            matB[2, 0] = float.Parse(textBox44.Text);
            matB[2, 1] = float.Parse(textBox43.Text);
            matB[2, 2] = float.Parse(textBox42.Text);
            matB[0, 2] = float.Parse(textBox40.Text);
            matB[1, 2] = float.Parse(textBox41.Text);
        }

        private void textToPolje4x4()
        {
            textToPolje3x3();
            matA[3, 0] = float.Parse(textBox10.Text);
            matA[3, 1] = float.Parse(textBox11.Text);
            matA[3, 2] = float.Parse(textBox12.Text);
            matA[3, 3] = float.Parse(textBox13.Text);
            matA[0, 3] = float.Parse(textBox16.Text);
            matA[1, 3] = float.Parse(textBox15.Text);
            matA[2, 3] = float.Parse(textBox14.Text);

            matB[3, 0] = float.Parse(textBox39.Text);
            matB[3, 1] = float.Parse(textBox38.Text);
            matB[3, 2] = float.Parse(textBox37.Text);
            matB[3, 3] = float.Parse(textBox36.Text);
            matB[0, 3] = float.Parse(textBox33.Text);
            matB[1, 3] = float.Parse(textBox34.Text);
            matB[2, 3] = float.Parse(textBox35.Text);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            foreach (Control text in panel2x2A.Controls)
            {
                if (text is TextBox)
                {
                    ((TextBox)text).Visible = false;
                }
            }

            foreach (Control text in panel3x3A.Controls)
            {
                if (text is TextBox)
                {
                    ((TextBox)text).Visible = false;
                }
            }

            foreach (Control text in panel4x4A.Controls)
            {
                if (text is TextBox)
                {
                    ((TextBox)text).Visible = false;
                }
            }

            foreach (Control text in panel2x2B.Controls)
            {
                if (text is TextBox)
                {
                    ((TextBox)text).Visible = false;
                }
            }

            foreach (Control text in panel3x3B.Controls)
            {
                if (text is TextBox)
                {
                    ((TextBox)text).Visible = false;
                }
            }

            foreach (Control text in panel4x4B.Controls)
            {
                if (text is TextBox)
                {
                    ((TextBox)text).Visible = false;
                }
            }

            foreach (Control text in panel2x2C.Controls)
            {
                if (text is TextBox)
                {
                    ((TextBox)text).Visible = false;
                }
            }

            foreach (Control text in panel3x3C.Controls)
            {
                if (text is TextBox)
                {
                    ((TextBox)text).Visible = false;
                }
            }

            foreach (Control text in panel4x4C.Controls)
            {
                if (text is TextBox)
                {
                    ((TextBox)text).Visible = false;
                }
            }

            if (numericUpDown1.Value == 2)
            {
                enable2x2();
            }
            else if (numericUpDown1.Value == 3)
            {
                enable3x3();
            }
            else if(numericUpDown1.Value == 4)
            {
                enable4x4();
            }
        }

        private void randomizerToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (numericUpDown1.Value == 2)
            {
                popuni2x2();
            }
            else if (numericUpDown1.Value == 3)
            {
                popuni3x3();
            }
            else if (numericUpDown1.Value == 4)
            {
                popuni4x4();
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if(numericUpDown1.Value == 2)
            {
                textToPolje2x2();

                for(int i = 0; i < 2; i++)
                {
                    for(int j = 0; j < 2; j++)
                    {
                        matC[i,j] = matA[i,j] + matB[i,j];  
                    }
                }

                textBox64.Text = matC[0,0].ToString();
                textBox63.Text = matC[0,1].ToString();
                textBox62.Text = matC[1,0].ToString();
                textBox61.Text = matC[1,1].ToString();
            }
            else if (numericUpDown1.Value == 3)
            {
                textToPolje3x3();

                for (int i = 0; i < 3; i++)
                {
                    for (int j = 0; j < 3; j++)
                    {
                        matC[i, j] = matA[i, j] + matB[i, j];
                    }
                }

                textBox64.Text = matC[0, 0].ToString();
                textBox63.Text = matC[0, 1].ToString();
                textBox56.Text = matC[0, 2].ToString();
                textBox62.Text = matC[1, 0].ToString();
                textBox61.Text = matC[1, 1].ToString();
                textBox57.Text = matC[1, 2].ToString();
                textBox60.Text = matC[2, 0].ToString();
                textBox59.Text = matC[2, 1].ToString();
                textBox58.Text = matC[2, 2].ToString();

            }
            else if (numericUpDown1.Value == 4)
            {
                textToPolje4x4();

                for (int i = 0; i < 4; i++)
                {
                    for (int j = 0; j < 4; j++)
                    {
                        matC[i, j] = matA[i, j] + matB[i, j];
                    }
                }

                textBox64.Text = matC[0, 0].ToString();
                textBox63.Text = matC[0, 1].ToString();
                textBox56.Text = matC[0, 2].ToString();
                textBox49.Text = matC[0, 3].ToString();
                textBox62.Text = matC[1, 0].ToString();
                textBox61.Text = matC[1, 1].ToString();
                textBox57.Text = matC[1, 2].ToString();
                textBox50.Text = matC[1, 3].ToString();
                textBox60.Text = matC[2, 0].ToString();
                textBox59.Text = matC[2, 1].ToString();
                textBox58.Text = matC[2, 2].ToString();
                textBox51.Text = matC[2, 3].ToString();
                textBox55.Text = matC[3, 0].ToString();
                textBox54.Text = matC[3, 1].ToString();
                textBox53.Text = matC[3, 2].ToString();
                textBox52.Text = matC[3, 3].ToString();
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (numericUpDown1.Value == 2)
            {
                textToPolje2x2();

                for (int i = 0; i < 2; i++)
                {
                    for (int j = 0; j < 2; j++)
                    {
                        matC[i, j] = matA[i, j] - matB[i, j];
                    }
                }

                textBox64.Text = matC[0, 0].ToString();
                textBox63.Text = matC[0, 1].ToString();
                textBox62.Text = matC[1, 0].ToString();
                textBox61.Text = matC[1, 1].ToString();
            }
            else if (numericUpDown1.Value == 3)
            {
                textToPolje3x3();

                for (int i = 0; i < 3; i++)
                {
                    for (int j = 0; j < 3; j++)
                    {
                        matC[i, j] = matA[i, j] - matB[i, j];
                    }
                }

                textBox64.Text = matC[0, 0].ToString();
                textBox63.Text = matC[0, 1].ToString();
                textBox56.Text = matC[0, 2].ToString();
                textBox62.Text = matC[1, 0].ToString();
                textBox61.Text = matC[1, 1].ToString();
                textBox57.Text = matC[1, 2].ToString();
                textBox60.Text = matC[2, 0].ToString();
                textBox59.Text = matC[2, 1].ToString();
                textBox58.Text = matC[2, 2].ToString();
            }
            else if (numericUpDown1.Value == 4)
            {
                textToPolje4x4();

                for (int i = 0; i < 4; i++)
                {
                    for (int j = 0; j < 4; j++)
                    {
                        matC[i, j] = matA[i, j] - matB[i, j];
                    }
                }

                textBox64.Text = matC[0, 0].ToString();
                textBox63.Text = matC[0, 1].ToString();
                textBox56.Text = matC[0, 2].ToString();
                textBox49.Text = matC[0, 3].ToString();
                textBox62.Text = matC[1, 0].ToString();
                textBox61.Text = matC[1, 1].ToString();
                textBox57.Text = matC[1, 2].ToString();
                textBox50.Text = matC[1, 3].ToString();
                textBox60.Text = matC[2, 0].ToString();
                textBox59.Text = matC[2, 1].ToString();
                textBox58.Text = matC[2, 2].ToString();
                textBox51.Text = matC[2, 3].ToString();
                textBox55.Text = matC[3, 0].ToString();
                textBox54.Text = matC[3, 1].ToString();
                textBox53.Text = matC[3, 2].ToString();
                textBox52.Text = matC[3, 3].ToString();
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            if (numericUpDown1.Value == 2)
            {
                textToPolje2x2();
                for (int i = 0; i < 2; i++)
                {
                    for (int j = 0; j < 2; j++)
                    {
                        matC[i,j] = 0;
                        for (int k = 0; k < 2; k++)
                        {
                            matC[i, j] += matA[i, k] * matB[k, j];
                        }
                    }
                }
                textBox64.Text = matC[0, 0].ToString();
                textBox63.Text = matC[0, 1].ToString();
                textBox62.Text = matC[1, 0].ToString();
                textBox61.Text = matC[1, 1].ToString();
            }
            else if (numericUpDown1.Value == 3)
            {
                textToPolje3x3();
                for (int i = 0; i < 3; i++)
                {
                    for (int j = 0; j < 3; j++)
                    {
                        matC[i, j] = 0;
                        for (int k = 0; k < 3; k++)
                        {
                            matC[i, j] += matA[i, k] * matB[k, j];
                        }
                    }
                }
                textBox64.Text = matC[0, 0].ToString();
                textBox63.Text = matC[0, 1].ToString();
                textBox56.Text = matC[0, 2].ToString();
                textBox62.Text = matC[1, 0].ToString();
                textBox61.Text = matC[1, 1].ToString();
                textBox57.Text = matC[1, 2].ToString();
                textBox60.Text = matC[2, 0].ToString();
                textBox59.Text = matC[2, 1].ToString();
                textBox58.Text = matC[2, 2].ToString();
            }
            else if (numericUpDown1.Value == 4)
            {
                textToPolje4x4();
                for (int i = 0; i < 4; i++)
                {
                    for (int j = 0; j < 4; j++)
                    {
                        matC[i, j] = 0;
                        for (int k = 0; k < 4; k++)
                        {
                            matC[i, j] += matA[i, k] * matB[k, j];
                        }
                    }
                }
                textBox64.Text = matC[0, 0].ToString();
                textBox63.Text = matC[0, 1].ToString();
                textBox56.Text = matC[0, 2].ToString();
                textBox49.Text = matC[0, 3].ToString();
                textBox62.Text = matC[1, 0].ToString();
                textBox61.Text = matC[1, 1].ToString();
                textBox57.Text = matC[1, 2].ToString();
                textBox50.Text = matC[1, 3].ToString();
                textBox60.Text = matC[2, 0].ToString();
                textBox59.Text = matC[2, 1].ToString();
                textBox58.Text = matC[2, 2].ToString();
                textBox51.Text = matC[2, 3].ToString();
                textBox55.Text = matC[3, 0].ToString();
                textBox54.Text = matC[3, 1].ToString();
                textBox53.Text = matC[3, 2].ToString();
                textBox52.Text = matC[3, 3].ToString();
            }
        }

        private void button5_Click(object sender, EventArgs e)
        {
            if (numericUpDown1.Value == 2)
            {
                textToPolje2x2();
                for (int i = 0; i < 2; i++)
                {
                    for (int j = 0; j < 2; j++)
                    {
                        matC[i, j] = 0;
                        for (int k = 0; k < 2; k++)
                        {
                            matC[i, j] += matB[i, k] * matA[k, j];
                        }
                    }
                }
                textBox64.Text = matC[0, 0].ToString();
                textBox63.Text = matC[0, 1].ToString();
                textBox62.Text = matC[1, 0].ToString();
                textBox61.Text = matC[1, 1].ToString();
            }
            else if (numericUpDown1.Value == 3)
            {
                textToPolje3x3();
                for (int i = 0; i < 3; i++)
                {
                    for (int j = 0; j < 3; j++)
                    {
                        matC[i, j] = 0;
                        for (int k = 0; k < 3; k++)
                        {
                            matC[i, j] += matB[i, k] * matA[k, j];
                        }
                    }
                }
                textBox64.Text = matC[0, 0].ToString();
                textBox63.Text = matC[0, 1].ToString();
                textBox56.Text = matC[0, 2].ToString();
                textBox62.Text = matC[1, 0].ToString();
                textBox61.Text = matC[1, 1].ToString();
                textBox57.Text = matC[1, 2].ToString();
                textBox60.Text = matC[2, 0].ToString();
                textBox59.Text = matC[2, 1].ToString();
                textBox58.Text = matC[2, 2].ToString();
            }
            else if (numericUpDown1.Value == 4)
            {
                textToPolje4x4();
                for (int i = 0; i < 4; i++)
                {
                    for (int j = 0; j < 4; j++)
                    {
                        matC[i, j] = 0;
                        for (int k = 0; k < 4; k++)
                        {
                            matC[i, j] += matB[i, k] * matA[k, j];
                        }
                    }
                }
                textBox64.Text = matC[0, 0].ToString();
                textBox63.Text = matC[0, 1].ToString();
                textBox56.Text = matC[0, 2].ToString();
                textBox49.Text = matC[0, 3].ToString();
                textBox62.Text = matC[1, 0].ToString();
                textBox61.Text = matC[1, 1].ToString();
                textBox57.Text = matC[1, 2].ToString();
                textBox50.Text = matC[1, 3].ToString();
                textBox60.Text = matC[2, 0].ToString();
                textBox59.Text = matC[2, 1].ToString();
                textBox58.Text = matC[2, 2].ToString();
                textBox51.Text = matC[2, 3].ToString();
                textBox55.Text = matC[3, 0].ToString();
                textBox54.Text = matC[3, 1].ToString();
                textBox53.Text = matC[3, 2].ToString();
                textBox52.Text = matC[3, 3].ToString();
            }
        }

        private void button6_Click(object sender, EventArgs e)
        {
            
        }

        private void button7_Click(object sender, EventArgs e)
        {
            if (numericUpDown1.Value == 2)
            {
                textToPolje2x2();
                double det = 0;
                double value = 0;
                int i, j, k;

                i = 2;
                j = 2;
                int n = i;

                for (i = 0; i < n - 1; i++)
                {
                    for (j = i + 1; j < n; j++)
                    {
                        det = (matA[j, i] / matA[i, i]);

                        for (k = i; k < n; k++)
                        {
                            value = matA[j, k] - det * matA[i, k];

                            matA[j, k] = (float)value;
                            //this.setElement(value, j, k);
                        }
                    }
                }
                det = 1;
                for (i = 0; i < n; i++)
                    det = det * matA[i, i];

                textBox17.Text = Math.Round(det, 2).ToString();
            }
            else if (numericUpDown1.Value == 3)
            {
                textToPolje3x3();
                double det = 0;
                double value = 0;
                int i, j, k;

                i = 3;
                j = 3;
                int n = i;

                for (i = 0; i < n - 1; i++)
                {
                    for (j = i + 1; j < n; j++)
                    {
                        det = (matA[j, i] / matA[i, i]);

                        for (k = i; k < n; k++)
                        {
                            value = matA[j, k] - det * matA[i, k];

                            matA[j, k] = (float)value;
                            //this.setElement(value, j, k);
                        }
                    }
                }
                det = 1;
                for (i = 0; i < n; i++)
                    det = det * matA[i, i];

                textBox17.Text = Math.Round(det, 2).ToString();
            }
            else if (numericUpDown1.Value == 4)
            {
                textToPolje4x4();
                double det = 0;
                double value = 0;
                int i, j, k;

                i = 4;
                j = 4;
                int n = i;

                for (i = 0; i < n - 1; i++)
                {
                    for (j = i + 1; j < n; j++)
                    {
                        det = (matA[j, i] / matA[i, i]);

                        for (k = i; k < n; k++)
                        {
                            value = matA[j, k] - det * matA[i, k];

                            matA[j, k] = (float)value;
                            //this.setElement(value, j, k);
                        }
                    }
                }
                det = 1;
                for (i = 0; i < n; i++)
                    det = det * matA[i, i];

                textBox17.Text = Math.Round(det,2).ToString();
            }
        }
    }
}
