﻿namespace WinFormsApp1
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.numericUpDown1 = new System.Windows.Forms.NumericUpDown();
            this.label1 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.panel4x4A = new System.Windows.Forms.Panel();
            this.textBox16 = new System.Windows.Forms.TextBox();
            this.textBox15 = new System.Windows.Forms.TextBox();
            this.textBox14 = new System.Windows.Forms.TextBox();
            this.textBox13 = new System.Windows.Forms.TextBox();
            this.textBox12 = new System.Windows.Forms.TextBox();
            this.textBox11 = new System.Windows.Forms.TextBox();
            this.textBox10 = new System.Windows.Forms.TextBox();
            this.panel3x3A = new System.Windows.Forms.Panel();
            this.textBox9 = new System.Windows.Forms.TextBox();
            this.textBox8 = new System.Windows.Forms.TextBox();
            this.textBox7 = new System.Windows.Forms.TextBox();
            this.textBox6 = new System.Windows.Forms.TextBox();
            this.textBox5 = new System.Windows.Forms.TextBox();
            this.panel2x2A = new System.Windows.Forms.Panel();
            this.textBox4 = new System.Windows.Forms.TextBox();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.panel4x4B = new System.Windows.Forms.Panel();
            this.textBox33 = new System.Windows.Forms.TextBox();
            this.textBox34 = new System.Windows.Forms.TextBox();
            this.textBox35 = new System.Windows.Forms.TextBox();
            this.textBox36 = new System.Windows.Forms.TextBox();
            this.textBox37 = new System.Windows.Forms.TextBox();
            this.textBox38 = new System.Windows.Forms.TextBox();
            this.textBox39 = new System.Windows.Forms.TextBox();
            this.panel3x3B = new System.Windows.Forms.Panel();
            this.textBox40 = new System.Windows.Forms.TextBox();
            this.textBox41 = new System.Windows.Forms.TextBox();
            this.textBox42 = new System.Windows.Forms.TextBox();
            this.textBox43 = new System.Windows.Forms.TextBox();
            this.textBox44 = new System.Windows.Forms.TextBox();
            this.panel2x2B = new System.Windows.Forms.Panel();
            this.textBox45 = new System.Windows.Forms.TextBox();
            this.textBox46 = new System.Windows.Forms.TextBox();
            this.textBox47 = new System.Windows.Forms.TextBox();
            this.textBox48 = new System.Windows.Forms.TextBox();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.randomizerToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.panel4x4C = new System.Windows.Forms.Panel();
            this.textBox49 = new System.Windows.Forms.TextBox();
            this.textBox50 = new System.Windows.Forms.TextBox();
            this.textBox51 = new System.Windows.Forms.TextBox();
            this.textBox52 = new System.Windows.Forms.TextBox();
            this.textBox53 = new System.Windows.Forms.TextBox();
            this.textBox54 = new System.Windows.Forms.TextBox();
            this.textBox55 = new System.Windows.Forms.TextBox();
            this.panel3x3C = new System.Windows.Forms.Panel();
            this.textBox56 = new System.Windows.Forms.TextBox();
            this.textBox57 = new System.Windows.Forms.TextBox();
            this.textBox58 = new System.Windows.Forms.TextBox();
            this.textBox59 = new System.Windows.Forms.TextBox();
            this.textBox60 = new System.Windows.Forms.TextBox();
            this.panel2x2C = new System.Windows.Forms.Panel();
            this.textBox61 = new System.Windows.Forms.TextBox();
            this.textBox62 = new System.Windows.Forms.TextBox();
            this.textBox63 = new System.Windows.Forms.TextBox();
            this.textBox64 = new System.Windows.Forms.TextBox();
            this.button2 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.button5 = new System.Windows.Forms.Button();
            this.button7 = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.textBox17 = new System.Windows.Forms.TextBox();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown1)).BeginInit();
            this.panel4x4A.SuspendLayout();
            this.panel3x3A.SuspendLayout();
            this.panel2x2A.SuspendLayout();
            this.panel4x4B.SuspendLayout();
            this.panel3x3B.SuspendLayout();
            this.panel2x2B.SuspendLayout();
            this.menuStrip1.SuspendLayout();
            this.panel4x4C.SuspendLayout();
            this.panel3x3C.SuspendLayout();
            this.panel2x2C.SuspendLayout();
            this.SuspendLayout();
            // 
            // numericUpDown1
            // 
            this.numericUpDown1.Location = new System.Drawing.Point(708, 36);
            this.numericUpDown1.Maximum = new decimal(new int[] {
            4,
            0,
            0,
            0});
            this.numericUpDown1.Minimum = new decimal(new int[] {
            2,
            0,
            0,
            0});
            this.numericUpDown1.Name = "numericUpDown1";
            this.numericUpDown1.Size = new System.Drawing.Size(84, 23);
            this.numericUpDown1.TabIndex = 37;
            this.numericUpDown1.Value = new decimal(new int[] {
            3,
            0,
            0,
            0});
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(612, 38);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(90, 15);
            this.label1.TabIndex = 38;
            this.label1.Text = "Veličina matrice";
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(640, 65);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(127, 23);
            this.button1.TabIndex = 43;
            this.button1.Text = "Generiraj matrice";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // panel4x4A
            // 
            this.panel4x4A.Controls.Add(this.textBox16);
            this.panel4x4A.Controls.Add(this.textBox15);
            this.panel4x4A.Controls.Add(this.textBox14);
            this.panel4x4A.Controls.Add(this.textBox13);
            this.panel4x4A.Controls.Add(this.textBox12);
            this.panel4x4A.Controls.Add(this.textBox11);
            this.panel4x4A.Controls.Add(this.textBox10);
            this.panel4x4A.Controls.Add(this.panel3x3A);
            this.panel4x4A.Location = new System.Drawing.Point(58, 36);
            this.panel4x4A.Name = "panel4x4A";
            this.panel4x4A.Size = new System.Drawing.Size(548, 285);
            this.panel4x4A.TabIndex = 44;
            // 
            // textBox16
            // 
            this.textBox16.Location = new System.Drawing.Point(425, 28);
            this.textBox16.Name = "textBox16";
            this.textBox16.Size = new System.Drawing.Size(100, 23);
            this.textBox16.TabIndex = 47;
            // 
            // textBox15
            // 
            this.textBox15.Location = new System.Drawing.Point(423, 91);
            this.textBox15.Name = "textBox15";
            this.textBox15.Size = new System.Drawing.Size(100, 23);
            this.textBox15.TabIndex = 46;
            // 
            // textBox14
            // 
            this.textBox14.Location = new System.Drawing.Point(423, 171);
            this.textBox14.Name = "textBox14";
            this.textBox14.Size = new System.Drawing.Size(100, 23);
            this.textBox14.TabIndex = 45;
            // 
            // textBox13
            // 
            this.textBox13.Location = new System.Drawing.Point(423, 237);
            this.textBox13.Name = "textBox13";
            this.textBox13.Size = new System.Drawing.Size(100, 23);
            this.textBox13.TabIndex = 11;
            // 
            // textBox12
            // 
            this.textBox12.Location = new System.Drawing.Point(292, 237);
            this.textBox12.Name = "textBox12";
            this.textBox12.Size = new System.Drawing.Size(100, 23);
            this.textBox12.TabIndex = 10;
            // 
            // textBox11
            // 
            this.textBox11.Location = new System.Drawing.Point(157, 237);
            this.textBox11.Name = "textBox11";
            this.textBox11.Size = new System.Drawing.Size(100, 23);
            this.textBox11.TabIndex = 9;
            // 
            // textBox10
            // 
            this.textBox10.Location = new System.Drawing.Point(21, 237);
            this.textBox10.Name = "textBox10";
            this.textBox10.Size = new System.Drawing.Size(100, 23);
            this.textBox10.TabIndex = 8;
            // 
            // panel3x3A
            // 
            this.panel3x3A.Controls.Add(this.textBox9);
            this.panel3x3A.Controls.Add(this.textBox8);
            this.panel3x3A.Controls.Add(this.textBox7);
            this.panel3x3A.Controls.Add(this.textBox6);
            this.panel3x3A.Controls.Add(this.textBox5);
            this.panel3x3A.Controls.Add(this.panel2x2A);
            this.panel3x3A.Location = new System.Drawing.Point(0, 0);
            this.panel3x3A.Name = "panel3x3A";
            this.panel3x3A.Size = new System.Drawing.Size(419, 219);
            this.panel3x3A.TabIndex = 0;
            // 
            // textBox9
            // 
            this.textBox9.Location = new System.Drawing.Point(292, 28);
            this.textBox9.Name = "textBox9";
            this.textBox9.Size = new System.Drawing.Size(100, 23);
            this.textBox9.TabIndex = 7;
            // 
            // textBox8
            // 
            this.textBox8.Location = new System.Drawing.Point(292, 91);
            this.textBox8.Name = "textBox8";
            this.textBox8.Size = new System.Drawing.Size(100, 23);
            this.textBox8.TabIndex = 4;
            // 
            // textBox7
            // 
            this.textBox7.Location = new System.Drawing.Point(292, 171);
            this.textBox7.Name = "textBox7";
            this.textBox7.Size = new System.Drawing.Size(100, 23);
            this.textBox7.TabIndex = 6;
            // 
            // textBox6
            // 
            this.textBox6.Location = new System.Drawing.Point(157, 171);
            this.textBox6.Name = "textBox6";
            this.textBox6.Size = new System.Drawing.Size(100, 23);
            this.textBox6.TabIndex = 5;
            // 
            // textBox5
            // 
            this.textBox5.Location = new System.Drawing.Point(21, 171);
            this.textBox5.Name = "textBox5";
            this.textBox5.Size = new System.Drawing.Size(100, 23);
            this.textBox5.TabIndex = 4;
            // 
            // panel2x2A
            // 
            this.panel2x2A.Controls.Add(this.textBox4);
            this.panel2x2A.Controls.Add(this.textBox3);
            this.panel2x2A.Controls.Add(this.textBox2);
            this.panel2x2A.Controls.Add(this.textBox1);
            this.panel2x2A.Location = new System.Drawing.Point(0, 0);
            this.panel2x2A.Name = "panel2x2A";
            this.panel2x2A.Size = new System.Drawing.Size(279, 151);
            this.panel2x2A.TabIndex = 0;
            // 
            // textBox4
            // 
            this.textBox4.Location = new System.Drawing.Point(157, 91);
            this.textBox4.Name = "textBox4";
            this.textBox4.Size = new System.Drawing.Size(100, 23);
            this.textBox4.TabIndex = 3;
            // 
            // textBox3
            // 
            this.textBox3.Location = new System.Drawing.Point(21, 91);
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(100, 23);
            this.textBox3.TabIndex = 2;
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(157, 28);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(100, 23);
            this.textBox2.TabIndex = 1;
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(21, 28);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(100, 23);
            this.textBox1.TabIndex = 0;
            // 
            // panel4x4B
            // 
            this.panel4x4B.Controls.Add(this.textBox33);
            this.panel4x4B.Controls.Add(this.textBox34);
            this.panel4x4B.Controls.Add(this.textBox35);
            this.panel4x4B.Controls.Add(this.textBox36);
            this.panel4x4B.Controls.Add(this.textBox37);
            this.panel4x4B.Controls.Add(this.textBox38);
            this.panel4x4B.Controls.Add(this.textBox39);
            this.panel4x4B.Controls.Add(this.panel3x3B);
            this.panel4x4B.Location = new System.Drawing.Point(58, 415);
            this.panel4x4B.Name = "panel4x4B";
            this.panel4x4B.Size = new System.Drawing.Size(548, 285);
            this.panel4x4B.TabIndex = 45;
            // 
            // textBox33
            // 
            this.textBox33.Location = new System.Drawing.Point(425, 28);
            this.textBox33.Name = "textBox33";
            this.textBox33.Size = new System.Drawing.Size(100, 23);
            this.textBox33.TabIndex = 47;
            // 
            // textBox34
            // 
            this.textBox34.Location = new System.Drawing.Point(423, 91);
            this.textBox34.Name = "textBox34";
            this.textBox34.Size = new System.Drawing.Size(100, 23);
            this.textBox34.TabIndex = 46;
            // 
            // textBox35
            // 
            this.textBox35.Location = new System.Drawing.Point(423, 171);
            this.textBox35.Name = "textBox35";
            this.textBox35.Size = new System.Drawing.Size(100, 23);
            this.textBox35.TabIndex = 45;
            // 
            // textBox36
            // 
            this.textBox36.Location = new System.Drawing.Point(423, 237);
            this.textBox36.Name = "textBox36";
            this.textBox36.Size = new System.Drawing.Size(100, 23);
            this.textBox36.TabIndex = 11;
            // 
            // textBox37
            // 
            this.textBox37.Location = new System.Drawing.Point(292, 237);
            this.textBox37.Name = "textBox37";
            this.textBox37.Size = new System.Drawing.Size(100, 23);
            this.textBox37.TabIndex = 10;
            // 
            // textBox38
            // 
            this.textBox38.Location = new System.Drawing.Point(157, 237);
            this.textBox38.Name = "textBox38";
            this.textBox38.Size = new System.Drawing.Size(100, 23);
            this.textBox38.TabIndex = 9;
            // 
            // textBox39
            // 
            this.textBox39.Location = new System.Drawing.Point(21, 237);
            this.textBox39.Name = "textBox39";
            this.textBox39.Size = new System.Drawing.Size(100, 23);
            this.textBox39.TabIndex = 8;
            // 
            // panel3x3B
            // 
            this.panel3x3B.Controls.Add(this.textBox40);
            this.panel3x3B.Controls.Add(this.textBox41);
            this.panel3x3B.Controls.Add(this.textBox42);
            this.panel3x3B.Controls.Add(this.textBox43);
            this.panel3x3B.Controls.Add(this.textBox44);
            this.panel3x3B.Controls.Add(this.panel2x2B);
            this.panel3x3B.Location = new System.Drawing.Point(0, 0);
            this.panel3x3B.Name = "panel3x3B";
            this.panel3x3B.Size = new System.Drawing.Size(419, 219);
            this.panel3x3B.TabIndex = 0;
            // 
            // textBox40
            // 
            this.textBox40.Location = new System.Drawing.Point(292, 28);
            this.textBox40.Name = "textBox40";
            this.textBox40.Size = new System.Drawing.Size(100, 23);
            this.textBox40.TabIndex = 7;
            // 
            // textBox41
            // 
            this.textBox41.Location = new System.Drawing.Point(292, 91);
            this.textBox41.Name = "textBox41";
            this.textBox41.Size = new System.Drawing.Size(100, 23);
            this.textBox41.TabIndex = 4;
            // 
            // textBox42
            // 
            this.textBox42.Location = new System.Drawing.Point(292, 171);
            this.textBox42.Name = "textBox42";
            this.textBox42.Size = new System.Drawing.Size(100, 23);
            this.textBox42.TabIndex = 6;
            // 
            // textBox43
            // 
            this.textBox43.Location = new System.Drawing.Point(157, 171);
            this.textBox43.Name = "textBox43";
            this.textBox43.Size = new System.Drawing.Size(100, 23);
            this.textBox43.TabIndex = 5;
            // 
            // textBox44
            // 
            this.textBox44.Location = new System.Drawing.Point(21, 171);
            this.textBox44.Name = "textBox44";
            this.textBox44.Size = new System.Drawing.Size(100, 23);
            this.textBox44.TabIndex = 4;
            // 
            // panel2x2B
            // 
            this.panel2x2B.Controls.Add(this.textBox45);
            this.panel2x2B.Controls.Add(this.textBox46);
            this.panel2x2B.Controls.Add(this.textBox47);
            this.panel2x2B.Controls.Add(this.textBox48);
            this.panel2x2B.Location = new System.Drawing.Point(0, 0);
            this.panel2x2B.Name = "panel2x2B";
            this.panel2x2B.Size = new System.Drawing.Size(279, 151);
            this.panel2x2B.TabIndex = 0;
            // 
            // textBox45
            // 
            this.textBox45.Location = new System.Drawing.Point(157, 91);
            this.textBox45.Name = "textBox45";
            this.textBox45.Size = new System.Drawing.Size(100, 23);
            this.textBox45.TabIndex = 3;
            // 
            // textBox46
            // 
            this.textBox46.Location = new System.Drawing.Point(21, 91);
            this.textBox46.Name = "textBox46";
            this.textBox46.Size = new System.Drawing.Size(100, 23);
            this.textBox46.TabIndex = 2;
            // 
            // textBox47
            // 
            this.textBox47.Location = new System.Drawing.Point(157, 28);
            this.textBox47.Name = "textBox47";
            this.textBox47.Size = new System.Drawing.Size(100, 23);
            this.textBox47.TabIndex = 1;
            // 
            // textBox48
            // 
            this.textBox48.Location = new System.Drawing.Point(21, 28);
            this.textBox48.Name = "textBox48";
            this.textBox48.Size = new System.Drawing.Size(100, 23);
            this.textBox48.TabIndex = 0;
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.randomizerToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(1305, 24);
            this.menuStrip1.TabIndex = 47;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // randomizerToolStripMenuItem
            // 
            this.randomizerToolStripMenuItem.Name = "randomizerToolStripMenuItem";
            this.randomizerToolStripMenuItem.Size = new System.Drawing.Size(82, 20);
            this.randomizerToolStripMenuItem.Text = "Randomizer";
            this.randomizerToolStripMenuItem.Click += new System.EventHandler(this.randomizerToolStripMenuItem_Click);
            // 
            // panel4x4C
            // 
            this.panel4x4C.Controls.Add(this.textBox49);
            this.panel4x4C.Controls.Add(this.textBox50);
            this.panel4x4C.Controls.Add(this.textBox51);
            this.panel4x4C.Controls.Add(this.textBox52);
            this.panel4x4C.Controls.Add(this.textBox53);
            this.panel4x4C.Controls.Add(this.textBox54);
            this.panel4x4C.Controls.Add(this.textBox55);
            this.panel4x4C.Controls.Add(this.panel3x3C);
            this.panel4x4C.Location = new System.Drawing.Point(745, 244);
            this.panel4x4C.Name = "panel4x4C";
            this.panel4x4C.Size = new System.Drawing.Size(548, 285);
            this.panel4x4C.TabIndex = 49;
            // 
            // textBox49
            // 
            this.textBox49.Location = new System.Drawing.Point(425, 28);
            this.textBox49.Name = "textBox49";
            this.textBox49.Size = new System.Drawing.Size(100, 23);
            this.textBox49.TabIndex = 47;
            // 
            // textBox50
            // 
            this.textBox50.Location = new System.Drawing.Point(423, 91);
            this.textBox50.Name = "textBox50";
            this.textBox50.Size = new System.Drawing.Size(100, 23);
            this.textBox50.TabIndex = 46;
            // 
            // textBox51
            // 
            this.textBox51.Location = new System.Drawing.Point(423, 171);
            this.textBox51.Name = "textBox51";
            this.textBox51.Size = new System.Drawing.Size(100, 23);
            this.textBox51.TabIndex = 45;
            // 
            // textBox52
            // 
            this.textBox52.Location = new System.Drawing.Point(423, 237);
            this.textBox52.Name = "textBox52";
            this.textBox52.Size = new System.Drawing.Size(100, 23);
            this.textBox52.TabIndex = 11;
            // 
            // textBox53
            // 
            this.textBox53.Location = new System.Drawing.Point(292, 237);
            this.textBox53.Name = "textBox53";
            this.textBox53.Size = new System.Drawing.Size(100, 23);
            this.textBox53.TabIndex = 10;
            // 
            // textBox54
            // 
            this.textBox54.Location = new System.Drawing.Point(157, 237);
            this.textBox54.Name = "textBox54";
            this.textBox54.Size = new System.Drawing.Size(100, 23);
            this.textBox54.TabIndex = 9;
            // 
            // textBox55
            // 
            this.textBox55.Location = new System.Drawing.Point(21, 237);
            this.textBox55.Name = "textBox55";
            this.textBox55.Size = new System.Drawing.Size(100, 23);
            this.textBox55.TabIndex = 8;
            // 
            // panel3x3C
            // 
            this.panel3x3C.Controls.Add(this.textBox56);
            this.panel3x3C.Controls.Add(this.textBox57);
            this.panel3x3C.Controls.Add(this.textBox58);
            this.panel3x3C.Controls.Add(this.textBox59);
            this.panel3x3C.Controls.Add(this.textBox60);
            this.panel3x3C.Controls.Add(this.panel2x2C);
            this.panel3x3C.Location = new System.Drawing.Point(0, 0);
            this.panel3x3C.Name = "panel3x3C";
            this.panel3x3C.Size = new System.Drawing.Size(419, 219);
            this.panel3x3C.TabIndex = 0;
            // 
            // textBox56
            // 
            this.textBox56.Location = new System.Drawing.Point(292, 28);
            this.textBox56.Name = "textBox56";
            this.textBox56.Size = new System.Drawing.Size(100, 23);
            this.textBox56.TabIndex = 7;
            // 
            // textBox57
            // 
            this.textBox57.Location = new System.Drawing.Point(292, 91);
            this.textBox57.Name = "textBox57";
            this.textBox57.Size = new System.Drawing.Size(100, 23);
            this.textBox57.TabIndex = 4;
            // 
            // textBox58
            // 
            this.textBox58.Location = new System.Drawing.Point(292, 171);
            this.textBox58.Name = "textBox58";
            this.textBox58.Size = new System.Drawing.Size(100, 23);
            this.textBox58.TabIndex = 6;
            // 
            // textBox59
            // 
            this.textBox59.Location = new System.Drawing.Point(157, 171);
            this.textBox59.Name = "textBox59";
            this.textBox59.Size = new System.Drawing.Size(100, 23);
            this.textBox59.TabIndex = 5;
            // 
            // textBox60
            // 
            this.textBox60.Location = new System.Drawing.Point(21, 171);
            this.textBox60.Name = "textBox60";
            this.textBox60.Size = new System.Drawing.Size(100, 23);
            this.textBox60.TabIndex = 4;
            // 
            // panel2x2C
            // 
            this.panel2x2C.Controls.Add(this.textBox61);
            this.panel2x2C.Controls.Add(this.textBox62);
            this.panel2x2C.Controls.Add(this.textBox63);
            this.panel2x2C.Controls.Add(this.textBox64);
            this.panel2x2C.Location = new System.Drawing.Point(0, 0);
            this.panel2x2C.Name = "panel2x2C";
            this.panel2x2C.Size = new System.Drawing.Size(279, 151);
            this.panel2x2C.TabIndex = 0;
            // 
            // textBox61
            // 
            this.textBox61.Location = new System.Drawing.Point(157, 91);
            this.textBox61.Name = "textBox61";
            this.textBox61.Size = new System.Drawing.Size(100, 23);
            this.textBox61.TabIndex = 3;
            // 
            // textBox62
            // 
            this.textBox62.Location = new System.Drawing.Point(21, 91);
            this.textBox62.Name = "textBox62";
            this.textBox62.Size = new System.Drawing.Size(100, 23);
            this.textBox62.TabIndex = 2;
            // 
            // textBox63
            // 
            this.textBox63.Location = new System.Drawing.Point(157, 28);
            this.textBox63.Name = "textBox63";
            this.textBox63.Size = new System.Drawing.Size(100, 23);
            this.textBox63.TabIndex = 1;
            // 
            // textBox64
            // 
            this.textBox64.Location = new System.Drawing.Point(21, 28);
            this.textBox64.Name = "textBox64";
            this.textBox64.Size = new System.Drawing.Size(100, 23);
            this.textBox64.TabIndex = 0;
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(640, 244);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(75, 23);
            this.button2.TabIndex = 50;
            this.button2.Text = "A + B";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(640, 298);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(75, 23);
            this.button3.TabIndex = 51;
            this.button3.Text = "A - B";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // button4
            // 
            this.button4.Location = new System.Drawing.Point(640, 351);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(75, 23);
            this.button4.TabIndex = 52;
            this.button4.Text = "A x B";
            this.button4.UseVisualStyleBackColor = true;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // button5
            // 
            this.button5.Location = new System.Drawing.Point(640, 395);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(75, 23);
            this.button5.TabIndex = 53;
            this.button5.Text = "B x A";
            this.button5.UseVisualStyleBackColor = true;
            this.button5.Click += new System.EventHandler(this.button5_Click);
            // 
            // button7
            // 
            this.button7.Location = new System.Drawing.Point(628, 443);
            this.button7.Name = "button7";
            this.button7.Size = new System.Drawing.Size(99, 23);
            this.button7.TabIndex = 55;
            this.button7.Text = "Determinanta A";
            this.button7.UseVisualStyleBackColor = true;
            this.button7.Click += new System.EventHandler(this.button7_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(753, 577);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(79, 15);
            this.label2.TabIndex = 56;
            this.label2.Text = "Determinanta";
            // 
            // textBox17
            // 
            this.textBox17.Location = new System.Drawing.Point(868, 574);
            this.textBox17.Name = "textBox17";
            this.textBox17.Size = new System.Drawing.Size(100, 23);
            this.textBox17.TabIndex = 57;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1305, 740);
            this.Controls.Add(this.textBox17);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.button7);
            this.Controls.Add(this.button5);
            this.Controls.Add(this.button4);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.panel4x4C);
            this.Controls.Add(this.menuStrip1);
            this.Controls.Add(this.panel4x4B);
            this.Controls.Add(this.panel4x4A);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.numericUpDown1);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "Form1";
            this.Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown1)).EndInit();
            this.panel4x4A.ResumeLayout(false);
            this.panel4x4A.PerformLayout();
            this.panel3x3A.ResumeLayout(false);
            this.panel3x3A.PerformLayout();
            this.panel2x2A.ResumeLayout(false);
            this.panel2x2A.PerformLayout();
            this.panel4x4B.ResumeLayout(false);
            this.panel4x4B.PerformLayout();
            this.panel3x3B.ResumeLayout(false);
            this.panel3x3B.PerformLayout();
            this.panel2x2B.ResumeLayout(false);
            this.panel2x2B.PerformLayout();
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.panel4x4C.ResumeLayout(false);
            this.panel4x4C.PerformLayout();
            this.panel3x3C.ResumeLayout(false);
            this.panel3x3C.PerformLayout();
            this.panel2x2C.ResumeLayout(false);
            this.panel2x2C.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.NumericUpDown numericUpDown1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Panel panel4x4A;
        private System.Windows.Forms.TextBox textBox13;
        private System.Windows.Forms.TextBox textBox12;
        private System.Windows.Forms.TextBox textBox11;
        private System.Windows.Forms.TextBox textBox10;
        private System.Windows.Forms.Panel panel3x3A;
        private System.Windows.Forms.TextBox textBox9;
        private System.Windows.Forms.TextBox textBox8;
        private System.Windows.Forms.TextBox textBox7;
        private System.Windows.Forms.TextBox textBox6;
        private System.Windows.Forms.TextBox textBox5;
        private System.Windows.Forms.Panel panel2x2A;
        private System.Windows.Forms.TextBox textBox4;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.TextBox textBox16;
        private System.Windows.Forms.TextBox textBox15;
        private System.Windows.Forms.TextBox textBox14;
        private System.Windows.Forms.Panel panel4x4B;
        private System.Windows.Forms.TextBox textBox33;
        private System.Windows.Forms.TextBox textBox34;
        private System.Windows.Forms.TextBox textBox35;
        private System.Windows.Forms.TextBox textBox36;
        private System.Windows.Forms.TextBox textBox37;
        private System.Windows.Forms.TextBox textBox38;
        private System.Windows.Forms.TextBox textBox39;
        private System.Windows.Forms.Panel panel3x3B;
        private System.Windows.Forms.TextBox textBox40;
        private System.Windows.Forms.TextBox textBox41;
        private System.Windows.Forms.TextBox textBox42;
        private System.Windows.Forms.TextBox textBox43;
        private System.Windows.Forms.TextBox textBox44;
        private System.Windows.Forms.Panel panel2x2B;
        private System.Windows.Forms.TextBox textBox45;
        private System.Windows.Forms.TextBox textBox46;
        private System.Windows.Forms.TextBox textBox47;
        private System.Windows.Forms.TextBox textBox48;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem randomizerToolStripMenuItem;
        private System.Windows.Forms.Panel panel4x4C;
        private System.Windows.Forms.TextBox textBox49;
        private System.Windows.Forms.TextBox textBox50;
        private System.Windows.Forms.TextBox textBox51;
        private System.Windows.Forms.TextBox textBox52;
        private System.Windows.Forms.TextBox textBox53;
        private System.Windows.Forms.TextBox textBox54;
        private System.Windows.Forms.TextBox textBox55;
        private System.Windows.Forms.Panel panel3x3C;
        private System.Windows.Forms.TextBox textBox56;
        private System.Windows.Forms.TextBox textBox57;
        private System.Windows.Forms.TextBox textBox58;
        private System.Windows.Forms.TextBox textBox59;
        private System.Windows.Forms.TextBox textBox60;
        private System.Windows.Forms.Panel panel2x2C;
        private System.Windows.Forms.TextBox textBox61;
        private System.Windows.Forms.TextBox textBox62;
        private System.Windows.Forms.TextBox textBox63;
        private System.Windows.Forms.TextBox textBox64;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Button button7;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox textBox17;
    }
}
