﻿using SimpleTCP;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ticTac_Client {
    public partial class Form1 : Form {
        public Form1() {
            InitializeComponent();
        }
        SimpleTcpClient client;
        String loginName;
        private void Form1_Load(object sender, EventArgs e) {
            client = new SimpleTcpClient();
            client.StringEncoder = Encoding.UTF8;
            client.DataReceived += Client_DataReceived;

        }

        private void Client_DataReceived(object sender, SimpleTCP.Message e) {
            listBox1.Invoke((MethodInvoker)delegate ()
            {
                client.DataReceived += Client_DataReceived;
                listBox1.Items.Add(e.MessageString);
                e.ReplyLine(string.Format("You said: {0}", e.MessageString));
                e.ReplyLine(string.Format("\n" + loginName + " said: {0}", e.MessageString));

            });
        }

        private void button1_Click(object sender, EventArgs e) {
            client = new SimpleTcpClient().Connect("127.0.0.1", Convert.ToInt32(textBox1.Text));
            button1.Enabled = false;
        }

        private void button3_Click(object sender, EventArgs e) {

        }

        private void button2_Click(object sender, EventArgs e) {
            String loginName = textBox3.Text;
            listBox1.Items.Add("\nYou said: " + textBox2.Text);
            client.WriteLineAndGetReply(loginName + " said: " + textBox2.Text, TimeSpan.FromSeconds(3));
        }
    }
}
