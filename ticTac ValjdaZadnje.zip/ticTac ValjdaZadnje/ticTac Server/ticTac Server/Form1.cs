﻿using SimpleTCP;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ticTac_Server {
    public partial class Form1 : Form {
        public Form1() {
            InitializeComponent();
            
        }
        SimpleTcpServer server;
        private String loginName;
        private void Form1_Load(object sender, EventArgs e) {
            server = new SimpleTcpServer();
            server.Delimiter = 0x13;
            server.StringEncoder = Encoding.UTF8;
            server.DataReceived += Server_DataReceived;
        }

        private void Server_DataReceived(object sender, SimpleTCP.Message e) {
            listBox1.Invoke((MethodInvoker)delegate ()
            {
                listBox1.Items.Add(e.MessageString + "\n");
                server.Broadcast(string.Format("\n" + loginName + " said: {0}", e.MessageString));

            });
        }

        private void button1_Click(object sender, EventArgs e) {
            listBox1.Items.Add("Server Starting...");
            server.Start(50000);
        }

        private void button3_Click(object sender, EventArgs e) {
            if (server.IsStarted) {
                server.Stop();
            }
        }

        private void button1_Click_1(object sender, EventArgs e) {
        }
    }
}
