﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace testKlient {
    public partial class Form1 : Form {
        public Form1() {
            InitializeComponent();
            Font LargeFont = new Font("Arial", 20);
            Font MediumFont = new Font("Arial", 25);
            label4.Font = LargeFont;
            label5.Font = LargeFont;
            button2.Font = MediumFont;
            button3.Font = MediumFont;
            button4.Font = MediumFont;
            button5.Font = MediumFont;
            button6.Font = MediumFont;
            button7.Font = MediumFont;
            button8.Font = MediumFont;
            button9.Font = MediumFont;
            button10.Font = MediumFont;
        }
        Thread konekcijaThread = null;
        Thread citajThread = null;

        string message = "Pobjednik je: ";
        string porukaError = "Greska kod unosa IP adrese i PORTA";
        string procitanoString = String.Empty;
        char[] ticTacPolje = { '0', '0', '0', '0', '0', '0', '0', '0', '0', '0','0','0','0','0'};//0 - 8 = buttoni 
                                                                                                 //9     = na redu
                                                                                                 //10    = started
                                                                                                 //11    = reset
                                                                                                 //12    = brojacX
                                                                                                 //13    = brojacY
        char[] poljeBrojeva = {'0','1','2','3' };

        Int32 port = 50300;
        IPAddress localAddr = IPAddress.Parse("127.0.0.1");

        bool naRedu = false; // 0 - KRIZIC    1 - KRUZIC
        char naReduString = '0';
        int brojac = 0;
        bool gameStarted = false;

        int brojacX = 0;
        int brojacY = 0;


        private void connectToolStripMenuItem_Click(object sender, EventArgs e) 
        {
            try 
            {
                port = Int32.Parse(textBox3.Text);
                localAddr = IPAddress.Parse(textBox2.Text);
                konekcijaThread = new Thread(funkcSpoji);
                label2.Invoke((MethodInvoker)(() => label2.Text = "Started"));
                konekcijaThread.Start();
            } 
            catch 
            {
                MessageBox.Show(porukaError);
            }
        }

        TcpClient tcpclnt = new TcpClient();
        void funkcSpoji() 
        {
            try 
            {

                tcpclnt.Connect(localAddr, port);
                label2.Invoke((MethodInvoker)(() => label2.Text = "Connected"));
                menuStrip1.Invoke((MethodInvoker)(() => startGameToolStripMenuItem.Enabled = true));
                //startGameToolStripMenuItem.Enabled = true;
                citajThread = new Thread(funckCitaj) ;
                citajThread.Start();
            } 
            catch (Exception e) 
            {
                label2.Invoke((MethodInvoker)(() => label2.Text = "Error"));
            }

            saljiPolje();
        }

        void funckCitaj() 
        {
            while (true)
            {
                Byte[] procitanoByte = new Byte[256];
                procitanoString = String.Empty;
                NetworkStream stream = tcpclnt.GetStream();
                Int32 bytes = stream.Read(procitanoByte, 0, procitanoByte.Length);
                procitanoString = System.Text.Encoding.ASCII.GetString(procitanoByte, 0, bytes);
                ticTacPolje = procitanoString.ToCharArray();

                label6.Invoke((MethodInvoker)(() => label6.Text = brojacX.ToString()));
                label7.Invoke((MethodInvoker)(() => label7.Text = procitanoString[13].ToString()));

                if (procitanoString[11] == '1')
                    resetiraj();

                if (procitanoString[10] == '1') 
                {
                    startGame();
                    startGameToolStripMenuItem.Enabled=true;
                }

                if (procitanoString[0] != '0')
                {
                    button2.Text = procitanoString[0].ToString();
                    button2.Enabled = false;
                }

                if (procitanoString[1] != '0')
                {
                    button3.Text = procitanoString[1].ToString();
                    button3.Enabled = false;
                }

                if (procitanoString[2] != '0')
                {
                    button4.Text = procitanoString[2].ToString();
                    button4.Enabled = false;
                }

                if (procitanoString[3] != '0')
                {
                    button5.Text = procitanoString[3].ToString();
                    button5.Enabled = false;
                }

                if (procitanoString[4] != '0')
                {
                    button6.Text = procitanoString[4].ToString();
                    button6.Enabled = false;
                }

                if (procitanoString[5] != '0')
                {
                    button7.Text = procitanoString[5].ToString();
                    button7.Enabled = false;
                }

                if (procitanoString[6] != '0')
                {
                    button8.Text = procitanoString[6].ToString();
                    button8.Enabled = false;
                }

                if (procitanoString[7] != '0')
                {
                    button9.Text = procitanoString[7].ToString();
                    button9.Enabled = false;
                }

                if (procitanoString[8] != '0')
                {
                    button10.Text = procitanoString[8].ToString();
                    button10.Enabled = false;
                }

                if (procitanoString[9] == '1')
                    naRedu = true;

                if(procitanoString[9] == '0')
                    naRedu = false;

                ispisNaRedu();
            }
        }

        private void saljiPolje() 
        {
            Byte[] data = new byte[ticTacPolje.Length];
            for (int i = 0; i < ticTacPolje.Length; i++)
            {
               data[i] = Convert.ToByte(ticTacPolje[i]);
            }
            
            NetworkStream stream = tcpclnt.GetStream();
            stream.Write(data, 0, data.Length);
        }

        void provjeriPobjednika()
        {
            if (button2.Text == button3.Text && button2.Text == button4.Text)
            {
                if (button2.Text == "X" || button2.Text == "O")
                {
                    message += button2.Text.ToString();
                    MessageBox.Show(message);
                    resetiraj();
                }
            }

            if (button2.Text == button5.Text && button2.Text == button8.Text)
            {
                if (button2.Text == "X" || button2.Text == "O")
                {
                    message += button2.Text.ToString();
                    MessageBox.Show(message);
                    resetiraj();

                }
            }

            if (button2.Text == button6.Text && button2.Text == button10.Text)
            {
                if (button2.Text == "X" || button2.Text == "O")
                {
                    message += button2.Text.ToString();
                    MessageBox.Show(message);
                    resetiraj();

                }
            }

            if (button3.Text == button6.Text && button3.Text == button9.Text)
            {
                if (button3.Text == "X" || button3.Text == "O")
                {
                    message += button3.Text.ToString();
                    MessageBox.Show(message);
                    resetiraj();
                }
            }

            if (button4.Text == button7.Text && button4.Text == button10.Text)
            {
                if (button4.Text == "X" || button4.Text == "O")
                {
                    message += button4.Text.ToString();
                    MessageBox.Show(message);
                    resetiraj();
                }
            }

            if (button4.Text == button6.Text && button4.Text == button8.Text)
            {
                if (button4.Text == "X" || button4.Text == "O")
                {
                    message += button4.Text.ToString();
                    MessageBox.Show(message);
                    resetiraj();
                }
            }

            if (button5.Text == button6.Text && button5.Text == button7.Text)
            {
                if (button5.Text == "X" || button5.Text == "O")
                {
                    message += button5.Text.ToString();
                    MessageBox.Show(message);
                    resetiraj();
                }
            }

            if (button8.Text == button9.Text && button8.Text == button10.Text)
            {
                if (button8.Text == "X" || button8.Text == "O")
                {
                    message += button8.Text.ToString();
                    MessageBox.Show(message);
                    resetiraj();
                }
            }

            if (brojac == 5) {
                message = "NERJEŠENO";
                MessageBox.Show(message);
                resetiraj();
            }
        }

        void resetiraj()
        {
            try {
                ticTacPolje[11] = '1';

                saljiPolje();

                button2.Text = "";
                button3.Text = "";
                button4.Text = "";
                button5.Text = "";
                button6.Text = "";
                button7.Text = "";
                button8.Text = "";
                button9.Text = "";
                button10.Text = "";

                button2.Enabled = true;
                button3.Enabled = true;
                button4.Enabled = true;
                button5.Enabled = true;
                button6.Enabled = true;
                button7.Enabled = true;
                button8.Enabled = true;
                button9.Enabled = true;
                button10.Enabled = true;

                naRedu = false;
                startGameToolStripMenuItem.Enabled = true;
                naReduString = '0';
                message = "Pobjednik je: ";
                procitanoString = String.Empty;
                for (int i = 0; i < ticTacPolje.Length; i++)
                    ticTacPolje[i] = '0';
            } catch { }
        }

        void ispisNaRedu()
        {
            if (!naRedu)
                label5.Invoke((MethodInvoker)(() => label5.Text = "Ti"));
            else
                label5.Invoke((MethodInvoker)(() => label5.Text = "Protivnik"));

            provjeriPobjednika();

            if (naRedu == true) {
                brojac++;
                if (brojac == 5)
                    provjeriPobjednika();
                nijeNaRedu();
            }

            if (naRedu == false && gameStarted == true) {
                jeNaRedu();
            }
        }

        void jeNaRedu() 
        {
            if (procitanoString[0] == '0')
                button2.Enabled = true;

            if (procitanoString[1] == '0')
                button3.Enabled = true;

            if (procitanoString[2] == '0')
                button4.Enabled = true;

            if (procitanoString[3] == '0')
                button5.Enabled = true;

            if (procitanoString[4] == '0')
                button6.Enabled = true;

            if (procitanoString[5] == '0')
                button7.Enabled = true;

            if (procitanoString[6] == '0')
                button8.Enabled = true;
            if (procitanoString[7] == '0')
                button9.Enabled = true;

            if (procitanoString[8] == '0')
                button10.Enabled = true;
        }

        void nijeNaRedu() {
            button2.Enabled = false;
            button3.Enabled = false;
            button4.Enabled = false;
            button5.Enabled = false;
            button6.Enabled = false;
            button7.Enabled = false;
            button8.Enabled = false;
            button9.Enabled = false;
            button10.Enabled = false;
        }

        private void startGame()
        {
            button2.Enabled = true;
            button3.Enabled = true;
            button4.Enabled = true;
            button5.Enabled = true;
            button6.Enabled = true;
            button7.Enabled = true;
            button8.Enabled = true;
            button9.Enabled = true;
            button10.Enabled = true;
            ticTacPolje[10] = '1';
            label5.Text = "Ti";
            gameStarted = true;
            startGameToolStripMenuItem.Enabled = false;
        }

        private void startGameToolStripMenuItem_Click(object sender, EventArgs e)
        {
            button2.Enabled = true;
            button3.Enabled = true;
            button4.Enabled = true;
            button5.Enabled = true;
            button6.Enabled = true;
            button7.Enabled = true;
            button8.Enabled = true;
            button9.Enabled = true;
            button10.Enabled = true;
            ticTacPolje[10] = '1';
            label5.Text = "Ti";
            gameStarted = true;
            startGameToolStripMenuItem.Enabled = false;

            saljiPolje();
        }

        void enableTipke() {
            if(naRedu == true && brojacX == 3) {
                if (procitanoString[0] == 'X')
                    button2.Enabled = true;

                if (procitanoString[1] == 'X')
                    button3.Enabled = true;

                if (procitanoString[2] == 'X')
                    button4.Enabled = true;

                if (procitanoString[3] == 'X')
                    button5.Enabled = true;

                if (procitanoString[4] == 'X')
                    button6.Enabled = true;

                if (procitanoString[5] == 'X')
                    button7.Enabled = true;

                if (procitanoString[6] == 'X')
                    button8.Enabled = true;

                if (procitanoString[7] == 'X')
                    button9.Enabled = true;

                if (procitanoString[8] == 'X')
                    button10.Enabled = true;
            }
        }



        private void button2_Click(object sender, EventArgs e) {
            if (naRedu == false) {
                naReduString = 'X';
                ticTacPolje[9] = '1';
                brojacX++;
            } else {
                naReduString = 'O';
                ticTacPolje[9] = '0';
                brojacY++;
            }

            naRedu = !naRedu;
            ispisNaRedu();

            button2.Text = naReduString.ToString();
            ticTacPolje[0] = naReduString;
            ticTacPolje[12] = poljeBrojeva[brojacX];
            ticTacPolje[13] = poljeBrojeva[brojacY];
            button2.Enabled = false;
            if (brojac == 3)
                enableTipke();
            saljiPolje();
        }

        private void button3_Click(object sender, EventArgs e) {
            if (naRedu == false) {
                naReduString = 'X';
                ticTacPolje[9] = '1';
                brojacX++;
            } else {
                naReduString = 'O';
                ticTacPolje[9] = '0';
                brojacY++;
            }

            naRedu = !naRedu;
            ispisNaRedu();

            button3.Text = naReduString.ToString();
            ticTacPolje[1] = naReduString;
            ticTacPolje[12] = poljeBrojeva[brojacX];
            ticTacPolje[13] = poljeBrojeva[brojacY];
            button3.Enabled = false;
            if (brojac == 3)
                enableTipke();
            saljiPolje();
        }

        private void button4_Click(object sender, EventArgs e) {
            if (naRedu == false) {
                naReduString = 'X';
                ticTacPolje[9] = '1';
                brojacX++;
            } else {
                naReduString = 'O';
                ticTacPolje[9] = '0';
                brojacY++;
            }

            naRedu = !naRedu;
            ispisNaRedu();

            button4.Text = naReduString.ToString();
            ticTacPolje[2] = naReduString;
            ticTacPolje[12] = poljeBrojeva[brojacX];
            ticTacPolje[13] = poljeBrojeva[brojacY];
            button4.Enabled = false;
            if (brojac == 3)
                enableTipke();
            saljiPolje();
        }

        private void button5_Click(object sender, EventArgs e) {
            if (naRedu == false) {
                naReduString = 'X';
                ticTacPolje[9] = '1';
                brojacX++;
            } else {
                naReduString = 'O';
                ticTacPolje[9] = '0';
                brojacY++;
            }

            naRedu = !naRedu;
            ispisNaRedu();

            button5.Text = naReduString.ToString();
            ticTacPolje[3] = naReduString;
            ticTacPolje[12] = poljeBrojeva[brojacX];
            ticTacPolje[13] = poljeBrojeva[brojacY];
            button5.Enabled = false;
            if (brojac == 3)
                enableTipke();
            saljiPolje();
        }

        private void button6_Click(object sender, EventArgs e) {
            if (naRedu == false) {
                naReduString = 'X';
                ticTacPolje[9] = '1';
                brojacX++;
            } else {
                naReduString = 'O';
                ticTacPolje[9] = '0';
                brojacY++;
            }

            naRedu = !naRedu;
            ispisNaRedu();

            button6.Text = naReduString.ToString();
            ticTacPolje[4] = naReduString;
            ticTacPolje[12] = poljeBrojeva[brojacX];
            ticTacPolje[13] = poljeBrojeva[brojacY];
            button6.Enabled = false;
            if (brojac == 3)
                enableTipke();
            saljiPolje();
        }

        private void button7_Click(object sender, EventArgs e) {
            if (naRedu == false) {
                naReduString = 'X';
                ticTacPolje[9] = '1';
                brojacX++;
            } else {
                naReduString = 'O';
                ticTacPolje[9] = '0';
                brojacY++;
            }

            naRedu = !naRedu;
            ispisNaRedu();

            button7.Text = naReduString.ToString();
            ticTacPolje[5] = naReduString;
            ticTacPolje[12] = poljeBrojeva[brojacX];
            ticTacPolje[13] = poljeBrojeva[brojacY];
            button7.Enabled = false;
            if (brojac == 3)
                enableTipke();
            saljiPolje();
        }

        private void button8_Click(object sender, EventArgs e) {
            if (naRedu == false) {
                naReduString = 'X';
                ticTacPolje[9] = '1';
                brojacX++;
            } else {
                naReduString = 'O';
                ticTacPolje[9] = '0';
                brojacY++;
            }

            naRedu = !naRedu;
            ispisNaRedu();

            button8.Text = naReduString.ToString();
            ticTacPolje[6] = naReduString;
            ticTacPolje[12] = poljeBrojeva[brojacX];
            ticTacPolje[13] = poljeBrojeva[brojacY];
            button8.Enabled = false;
            if (brojac == 3)
                enableTipke();
            saljiPolje();
        }

        private void button9_Click(object sender, EventArgs e) {
            if (naRedu == false) {
                naReduString = 'X';
                ticTacPolje[9] = '1';
                brojacX++;
            } else {
                naReduString = 'O';
                ticTacPolje[9] = '0';
                brojacY++;
            }

            naRedu = !naRedu;
            ispisNaRedu();

            button9.Text = naReduString.ToString();
            ticTacPolje[7] = naReduString;
            ticTacPolje[12] = poljeBrojeva[brojacX];
            ticTacPolje[13] = poljeBrojeva[brojacY];
            button9.Enabled = false;
            if (brojac == 3)
                enableTipke();
            saljiPolje();
        }

        private void button10_Click(object sender, EventArgs e) {
            if (naRedu == false) {
                naReduString = 'X';
                ticTacPolje[9] = '1';
                brojacX++;
            } else {
                naReduString = 'O';
                ticTacPolje[9] = '0';
                brojacY++;
            }

            naRedu = !naRedu;
            ispisNaRedu();

            button10.Text = naReduString.ToString();
            ticTacPolje[8] = naReduString;
            ticTacPolje[12] = poljeBrojeva[brojacX];
            ticTacPolje[13] = poljeBrojeva[brojacY];
            button10.Enabled = false;
            if (brojac == 3)
                enableTipke();
            saljiPolje();
        }

        private void Form1_FormClosed(object sender, FormClosedEventArgs e)
        {
            Environment.Exit(Environment.ExitCode);

        }

        private void panel1_Paint(object sender, PaintEventArgs e) {

        }
    }
}
